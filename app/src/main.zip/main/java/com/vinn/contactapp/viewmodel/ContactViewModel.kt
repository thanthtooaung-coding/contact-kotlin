package com.vinn.contactapp.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.vinn.contactapp.data.Contact
import com.vinn.contactapp.data.ContactDatabase
import com.vinn.contactapp.data.ContactRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

enum class ContactFilter { ALL, FAVORITES, TRASH }

// Helper data class to combine filter and query for switchMap trigger
private data class FilterAndQuery(val filter: ContactFilter, val query: String)

class ContactViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ContactRepository

    // LiveData for filter and search query
    private val _filterState = MutableLiveData(ContactFilter.ALL)
    val currentFilter: LiveData<ContactFilter> = _filterState // Expose filter state

    private val _searchQuery = MutableLiveData("")
    // No need to expose search query directly if only used internally

    // LiveData that combines filter and query changes
    private val filterAndQuery = MediatorLiveData<FilterAndQuery>().apply {
        addSource(_filterState) { filter ->
            value = FilterAndQuery(filter, _searchQuery.value ?: "")
        }

        // --- THIS IS THE FIX ---
        // When the query changes, simply update the mediator with the new query
        // and the current filter. The logic in setFilter/setSearchQuery
        // already controls *when* the query is allowed to change.
        addSource(_searchQuery) { query ->
            value = FilterAndQuery(_filterState.value!!, query)
        }
    }

    // The main LiveData exposed to the UI, driven by filterAndQuery changes
    val filteredContacts: LiveData<List<Contact>> = filterAndQuery.switchMap { params ->
        when (params.filter) {
            ContactFilter.ALL -> {
                val q = params.query.trim()
                if (q.isEmpty()) {
                    repository.allActiveContacts
                } else {
                    repository.searchActiveContacts("%$q%")
                }
            }
            ContactFilter.FAVORITES -> repository.favoriteContacts
            ContactFilter.TRASH -> repository.deletedContacts
        }
    }


    init {
        val contactDao = ContactDatabase.getDatabase(application).contactDao()
        repository = ContactRepository(contactDao)
        // Initialize the combined LiveData
        filterAndQuery.value = FilterAndQuery(ContactFilter.ALL, "")
    }

    // --- Actions ---

    fun insert(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(contact)
    }

    fun update(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        repository.update(contact)
    }

    // Soft delete
    fun delete(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        repository.markAsDeleted(contact)
    }

    fun restore(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        repository.restoreContact(contact)
    }

    fun deletePermanently(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        repository.deletePermanently(contact)
    }

    fun toggleFavorite(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        repository.toggleFavorite(contact)
    }

    fun emptyTrash() = viewModelScope.launch(Dispatchers.IO) {
        repository.emptyTrash()
    }


    // --- UI State Management ---

    fun setFilter(filter: ContactFilter) {
        val oldFilter = _filterState.value

        // Clear search query if switching away from ALL
        if (filter != ContactFilter.ALL && oldFilter == ContactFilter.ALL) {
            // Only update if query isn't already empty
            if (_searchQuery.value != "") {
                _searchQuery.value = "" // This will trigger the MediatorLiveData update
            }
        }

        // Only update if filter is actually changing
        if (oldFilter != filter) {
            _filterState.value = filter // This will also trigger the MediatorLiveData update
        }
    }

    fun setSearchQuery(query: String) {
        val trimmedQuery = query.trim()

        // We only update if the query has *actually* changed.
        // The logic to check for the filter state (ALL, etc.)
        // is now handled by the Fragment's new logic.
        if (_searchQuery.value != trimmedQuery) {
            Log.d("ContactViewModel", "setSearchQuery: Updating query to '$trimmedQuery'")
            _searchQuery.value = trimmedQuery // This will trigger the MediatorLiveData update
        } else {
            Log.d("ContactViewModel", "setSearchQuery: Query '$trimmedQuery' is the same. Ignoring.")
        }
    }

    fun getSearchQuery(): String {
        return _searchQuery.value ?: ""
    }
}
